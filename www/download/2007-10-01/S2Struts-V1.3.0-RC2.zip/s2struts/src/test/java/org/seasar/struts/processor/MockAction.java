package org.seasar.struts.processor;

import org.apache.struts.action.Action;

/**
 * 
 * @author Katsuhiko Nagashima
 *
 */
public class MockAction extends Action {

}
