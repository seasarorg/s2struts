package org.seasar.struts.pojo;

public interface TestPojoAction {

    String execute();

}
