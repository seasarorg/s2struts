package org.seasar.struts.config;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public class TestNoRegisteredComponentActionImpl implements TestNoRegisteredComponentAction {

    public String exe() {
        return null;
    }

}
