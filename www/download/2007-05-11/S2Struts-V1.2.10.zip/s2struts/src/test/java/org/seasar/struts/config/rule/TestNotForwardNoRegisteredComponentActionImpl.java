package org.seasar.struts.config.rule;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public class TestNotForwardNoRegisteredComponentActionImpl implements TestForwardNoRegisteredComponentAction {

    public String exe() {
        return null;
    }

}
