package org.seasar.struts.action;

/**
 * @author Katsuhiko Nagashima
 */
public interface ExportPOJOAnnotationAction {
	
	String exe();

}
