package org.seasar.struts.form;

/**
 * @author Katsuhiko Nagashima
 * @org.seasar.struts.annotation.backport175.StrutsActionForm(name = "testFormName")
 */
public class StrutsConfigAnnotationForm {

}
