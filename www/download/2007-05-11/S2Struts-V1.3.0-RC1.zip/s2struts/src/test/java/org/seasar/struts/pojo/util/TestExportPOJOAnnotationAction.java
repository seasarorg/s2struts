package org.seasar.struts.pojo.util;

/**
 * @author Katsuhiko Nagashima
 */
public interface TestExportPOJOAnnotationAction {
	
	String exe();

}
