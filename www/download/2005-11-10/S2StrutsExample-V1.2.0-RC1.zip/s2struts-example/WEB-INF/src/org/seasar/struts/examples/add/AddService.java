package org.seasar.struts.examples.add;

/**
 * @author higa
 * @author Satoshi Kimura
 */
public interface AddService {

	public int add(int arg1, int arg2);
}
