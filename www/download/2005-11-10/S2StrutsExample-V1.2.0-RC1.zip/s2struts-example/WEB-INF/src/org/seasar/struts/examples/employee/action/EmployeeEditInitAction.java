package org.seasar.struts.examples.employee.action;

/**
 * 
 * @author Katsuhiko Nagashima
 *
 */
public interface EmployeeEditInitAction {

    public String initialize();
    
}
