package org.seasar.struts.examples.validate;

import org.seasar.struts.examples.FowardNameConstants;

/**
 * @author Satoshi Kimura
 */
public class ValidateActionImpl implements ValidateAction {

    public String exe() {
        return FowardNameConstants.SUCCESS;
    }
    
    
}
