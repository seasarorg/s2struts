package org.seasar.struts.examples.exception;

public class BadCriteriaRuntimeException extends AppRuntimeException {

	public BadCriteriaRuntimeException() {
		super("examples.jsf.BadCriteria");
	}
}