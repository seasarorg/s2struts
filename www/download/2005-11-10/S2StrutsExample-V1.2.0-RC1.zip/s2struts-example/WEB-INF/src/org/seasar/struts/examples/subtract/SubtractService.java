package org.seasar.struts.examples.subtract;

/**
 * @author Satoshi Kimura
 */
public interface SubtractService {

	public int subtract(int arg1, int arg2);
}
