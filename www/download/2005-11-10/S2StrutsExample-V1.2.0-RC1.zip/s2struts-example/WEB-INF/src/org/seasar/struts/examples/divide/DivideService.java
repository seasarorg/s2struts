package org.seasar.struts.examples.divide;

/**
 * @author Satoshi Kimura
 */
public interface DivideService {

	public int divide(int arg1, int arg2);
}
