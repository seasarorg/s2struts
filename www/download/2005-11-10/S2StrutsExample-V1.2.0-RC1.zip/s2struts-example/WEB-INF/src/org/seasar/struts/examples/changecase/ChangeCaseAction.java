package org.seasar.struts.examples.changecase;

/**
 * @author Satoshi Kimura
 */
public interface ChangeCaseAction {
    String toLowerCase();

    String toUpperCase();
}