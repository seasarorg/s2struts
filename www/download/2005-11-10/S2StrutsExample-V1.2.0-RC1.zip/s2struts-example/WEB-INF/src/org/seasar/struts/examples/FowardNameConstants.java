package org.seasar.struts.examples;

/**
 * @author Satoshi Kimura
 */
public interface FowardNameConstants {
    String SUCCESS = "success";
}