package org.seasar.struts.examples.echo;

/**
 * @author Satoshi Kimura
 */
public interface EchoAction {
	String echo();
}
