package org.seasar.struts.examples.common;

public interface Constants {

	public int CREATE_MODE = 1;
	
	public int UPDATE_MODE = 2;
	
	public int DELETE_MODE = 3;
	
	public int REFER_MODE = 4;
}
