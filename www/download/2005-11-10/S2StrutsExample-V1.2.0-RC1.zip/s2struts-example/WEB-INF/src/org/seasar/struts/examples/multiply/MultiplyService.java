package org.seasar.struts.examples.multiply;

/**
 * @author Satoshi Kimura
 */
public interface MultiplyService {

	public int multiply(int arg1, int arg2);
}
