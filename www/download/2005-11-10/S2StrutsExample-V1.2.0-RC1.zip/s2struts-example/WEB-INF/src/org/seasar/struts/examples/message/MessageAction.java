package org.seasar.struts.examples.message;

/**
 * @author Satoshi Kimura
 * 
 */
public interface MessageAction {
    String execute();
}
