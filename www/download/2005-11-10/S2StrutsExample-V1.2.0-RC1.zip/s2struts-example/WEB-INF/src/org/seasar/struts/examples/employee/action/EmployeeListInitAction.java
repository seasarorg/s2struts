package org.seasar.struts.examples.employee.action;

/**
 * 
 * @author Katsuhiko Nagashima
 *
 */
public interface EmployeeListInitAction {

    public String initialize();
    
}
