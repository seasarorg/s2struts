package org.seasar.struts.examples.employee.action;

/**
 * 
 * @author Katsuhiko Nagashima
 *
 */
public interface EmployeeConfirmInitAction {

    public String initialize();
    
}
