package org.seasar.struts.examples.mod;

/**
 * @author Katsuhiko Nagashima
 */
public interface ModService {
	
	public int mod(int arg1, int arg2);
	
}
