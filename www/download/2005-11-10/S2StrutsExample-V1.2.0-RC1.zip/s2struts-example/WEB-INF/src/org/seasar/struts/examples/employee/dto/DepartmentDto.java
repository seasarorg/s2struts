package org.seasar.struts.examples.employee.dto;

import org.seasar.struts.examples.employee.entity.Department;

public class DepartmentDto extends Department {
}
