package org.seasar.struts.examples.form;

/**
 * @author Satoshi Kimura
 */
public class StringForm {
    private String input;
    private String result;

    public StringForm() {
    }

    public String getInput() {
        return input;
    }
    public void setInput(String input) {
        this.input = input;
    }
    public String getResult() {
        return result;
    }
    public void setResult(String result) {
        this.result = result;
    }
}