package org.seasar.struts.examples.mod;

/**
 * @author Katsuhiko Nagashima
 */
public class ModInputActionImpl implements ModInputAction {

	public String input() {
		return SUCCESS;
	}

}