package org.seasar.struts.action;


/**
 * @author Satoshi Kimura
 */
public class TestActionImpl implements TestAction {

    public TestActionImpl() {
    }

    public String exe() {
        return SUCCESS;
    }
}
