package org.seasar.struts.validator.annotation.backport175;

/**
 * @author Katsuhiko Nagashima
 * @org.seasar.struts.validator.annotation.backport175.ValidatorTarget
 */
public interface Maxbytelength {

    int value();
    
    String charset();
}
