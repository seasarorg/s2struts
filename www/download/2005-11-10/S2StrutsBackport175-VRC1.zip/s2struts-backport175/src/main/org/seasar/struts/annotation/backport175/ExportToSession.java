package org.seasar.struts.annotation.backport175;

/**
 * @author Satoshi Kimura
 */
public interface ExportToSession {
}
