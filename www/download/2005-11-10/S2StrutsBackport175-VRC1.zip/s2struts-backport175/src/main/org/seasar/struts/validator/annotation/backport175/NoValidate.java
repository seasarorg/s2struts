package org.seasar.struts.validator.annotation.backport175;

/**
 * @author Katsuhiko Nagashima
 */
public interface NoValidate {

}
