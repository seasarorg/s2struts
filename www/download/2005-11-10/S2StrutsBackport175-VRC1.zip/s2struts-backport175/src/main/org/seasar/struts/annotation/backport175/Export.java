package org.seasar.struts.annotation.backport175;

/**
 * @author Katsuhiko Nagashima
 */
public interface Export {
    
    String value();
    
}
