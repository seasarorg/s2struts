package org.seasar.struts.validator.annotation.backport175;

/**
 * @author Katsuhiko Nagashima
 * @org.seasar.struts.validator.annotation.backport175.ValidatorTarget
 */
public interface ValidatorField {

    /**
     * @org.codehaus.backport175.DefaultValue ()
     */
    Validator[] validators();

}