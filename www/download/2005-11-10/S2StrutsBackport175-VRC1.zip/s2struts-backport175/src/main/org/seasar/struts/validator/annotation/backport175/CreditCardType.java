package org.seasar.struts.validator.annotation.backport175;

/**
 * @author Satoshi Kimura
 * @org.seasar.struts.validator.annotation.backport175.ValidatorTarget
 */
public interface CreditCardType {

}
