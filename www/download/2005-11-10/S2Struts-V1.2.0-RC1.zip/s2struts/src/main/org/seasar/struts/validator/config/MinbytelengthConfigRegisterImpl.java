package org.seasar.struts.validator.config;

/**
 * @author Katsuhiko Nagashima
 */
public class MinbytelengthConfigRegisterImpl extends AbstractBytelengthConfigRegister {

    protected String getType() {
        return "minbytelength";
    }

}