package org.seasar.struts.validator.config;

/**
 * @author Satoshi Kimura
 */
public class MaxlengthConfigRegisterImpl extends AbstractLengthConfigRegister {

    protected String getType() {
        return "maxlength";
    }

}