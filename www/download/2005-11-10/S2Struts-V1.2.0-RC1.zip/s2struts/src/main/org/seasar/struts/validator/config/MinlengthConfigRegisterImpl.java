package org.seasar.struts.validator.config;

/**
 * @author Satoshi Kimura
 */
public class MinlengthConfigRegisterImpl extends AbstractLengthConfigRegister {

    protected String getType() {
        return "minlength";
    }

}