package org.seasar.struts.validator.config;

/**
 * @author Katsuhiko Nagashima
 */
public class FloatRangeConfigRegisterImpl extends AbstractRangeConfigRegister {

    protected String getType() {
        return "floatRange";
    }

}