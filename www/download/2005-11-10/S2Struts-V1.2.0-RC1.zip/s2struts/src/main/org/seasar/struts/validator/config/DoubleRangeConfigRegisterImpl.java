package org.seasar.struts.validator.config;

/**
 * @author Katsuhiko Nagashima
 */
public class DoubleRangeConfigRegisterImpl extends AbstractRangeConfigRegister {

    protected String getType() {
        return "doubleRange";
    }

}