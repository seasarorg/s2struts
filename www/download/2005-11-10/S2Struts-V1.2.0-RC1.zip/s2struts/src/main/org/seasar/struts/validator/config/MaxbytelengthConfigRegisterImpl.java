package org.seasar.struts.validator.config;

/**
 * @author Katsuhiko Nagashima
 */
public class MaxbytelengthConfigRegisterImpl extends AbstractBytelengthConfigRegister {

    protected String getType() {
        return "maxbytelength";
    }

}