package org.seasar.struts.validator.config;

/**
 * @author Katsuhiko Nagashima
 */
public class IntRangeConfigRegisterImpl extends AbstractRangeConfigRegister {

    protected String getType() {
        return "intRange";
    }

}