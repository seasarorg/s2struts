package org.seasar.struts.context;

/**
 * @author Satoshi Kimura
 */
public interface ContentsType {
    ContentsType MethodBindingExpression = new ContentsType() {
    };
    
}
