package org.seasar.struts.pojo.util;

public class TestPackageComponentOneForm {

}
