package org.seasar.struts.pojo.commands;

/**
 * @author Satoshi Kimura
 */
public interface TestReturnNullPOJOAction {
    String exe();

}
