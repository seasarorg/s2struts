package org.seasar.struts.config.rule;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public interface TestNotForwardSimpleAction {

}
