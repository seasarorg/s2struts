package org.seasar.struts.action;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public class TestComponent1ActionImpl implements TestComponent1Action {

    public String exe() {
        return null;
    }

}
