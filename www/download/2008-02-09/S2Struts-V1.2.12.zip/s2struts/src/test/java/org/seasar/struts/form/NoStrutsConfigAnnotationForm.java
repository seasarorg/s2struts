package org.seasar.struts.form;

/**
 * @author Katsuhiko Nagashima
 */
public class NoStrutsConfigAnnotationForm extends StrutsConfigAnnotationForm {

}
