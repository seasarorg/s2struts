/* set true/false */
var debug = true;

if (debug) {
    load("dump.js");
}
