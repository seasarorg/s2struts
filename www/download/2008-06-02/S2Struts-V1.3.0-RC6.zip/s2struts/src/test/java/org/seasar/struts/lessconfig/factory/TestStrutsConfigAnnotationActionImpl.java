package org.seasar.struts.lessconfig.factory;

/**
 * @author Satoshi Kimura
 */
public class TestStrutsConfigAnnotationActionImpl implements TestStrutsConfigAnnotationAction {

    public TestStrutsConfigAnnotationActionImpl() {
    }

    public String exe() {
        return SUCCESS;
    }
}
