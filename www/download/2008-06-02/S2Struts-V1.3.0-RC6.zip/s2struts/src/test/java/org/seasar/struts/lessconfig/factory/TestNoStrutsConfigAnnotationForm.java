package org.seasar.struts.lessconfig.factory;

/**
 * @author Katsuhiko Nagashima
 */
public class TestNoStrutsConfigAnnotationForm extends TestStrutsConfigAnnotationForm {

}
