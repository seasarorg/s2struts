package org.seasar.struts.form;

public class ValidatorAnnotationOrderForm {

    /**
     * @org.seasar.struts.validator.annotation.backport175.ValidateOrder(1)
     * @org.seasar.struts.validator.annotation.backport175.Required
     */
    public void setClassType(String classType) {
    }

    public static final int className_VALIDATOR_ORDER = 2;

    /**
     * @org.seasar.struts.validator.annotation.backport175.Required
     */
    public void setClassName(String className) {
    }

    /**
     * @org.seasar.struts.validator.annotation.backport175.ValidateOrder(3)
     * @org.seasar.struts.validator.annotation.backport175.Required
     */
    public void setArg(String arg) {
    }

}
