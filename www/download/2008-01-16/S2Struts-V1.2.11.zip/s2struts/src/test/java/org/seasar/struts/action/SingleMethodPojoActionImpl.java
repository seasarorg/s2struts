package org.seasar.struts.action;

public class SingleMethodPojoActionImpl implements SingleMethodPojoAction {

    public String exe() {
        return "success";
    }

}
