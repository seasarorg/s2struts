package org.seasar.struts.config;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public class TestIgnoreTargetImpl implements TestIgnoreTarget {

    public String exe() {
        return null;
    }

}
