package org.seasar.struts.form;

/**
 * @author Katsuhiko Nagashima
 */
public class StrutsConfigAnnotationForm {

    public static final String FORM = "testFormName";

}
