package org.seasar.struts.util;

public class TestPackageComponentOneForm {

}
