package org.seasar.struts.config;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public interface TestNoRegisteredComponentAction {

    String exe();

}
