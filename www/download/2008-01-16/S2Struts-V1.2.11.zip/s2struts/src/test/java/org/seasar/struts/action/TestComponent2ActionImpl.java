package org.seasar.struts.action;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public class TestComponent2ActionImpl implements TestComponent2Action {

    public String exe() {
        return null;
    }

}
