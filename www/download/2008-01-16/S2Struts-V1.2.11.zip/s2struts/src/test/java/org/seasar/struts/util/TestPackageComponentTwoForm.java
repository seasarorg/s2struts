package org.seasar.struts.util;

public class TestPackageComponentTwoForm {

}
