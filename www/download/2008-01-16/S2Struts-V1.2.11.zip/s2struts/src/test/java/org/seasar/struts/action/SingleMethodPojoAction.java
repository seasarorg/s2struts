package org.seasar.struts.action;

/**
 * 
 * @author Katsuhiko Nagashima
 */
public interface SingleMethodPojoAction {

    String exe();

}
