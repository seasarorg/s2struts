package org.seasar.struts.lessconfig.autoregister.impl;

public class TestHogeAction {

    String ACTION = "path=testHoge";

}
