package org.seasar.struts.lessconfig.autoregister.impl;

public class TestConfigCreatorAction {
    
    public static final String SUCCESS_FORWARD = "/testCreate.jsp";
    
    public static final String SUCCESS = "success";
    
}
