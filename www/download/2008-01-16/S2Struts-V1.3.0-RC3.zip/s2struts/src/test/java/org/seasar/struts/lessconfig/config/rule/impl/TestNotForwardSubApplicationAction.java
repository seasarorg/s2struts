package org.seasar.struts.lessconfig.config.rule.impl;

/**
 * 
 * @author Katsuhiko Nagashima
 *
 */
public interface TestNotForwardSubApplicationAction {

}
