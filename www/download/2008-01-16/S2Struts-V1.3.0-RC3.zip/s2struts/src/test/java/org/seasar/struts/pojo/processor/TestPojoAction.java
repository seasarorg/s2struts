package org.seasar.struts.pojo.processor;

/**
 * 
 * @author Katsuhiko Nagashima
 *
 */
public interface TestPojoAction {

}
