package org.seasar.struts.pojo;

public interface TestMethodBindingAction {
    
    String exe();
    
    String exe(int index);
    
    String download();

}
