package org.seasar.struts.pojo.util;

/**
 * @author Satoshi Kimura
 */
public interface TestPOJOAction {
    String exe();

}
