package org.seasar.struts.action;

/**
 * @author Satoshi Kimura
 */
public interface POJOAction {
    String exe();

}
