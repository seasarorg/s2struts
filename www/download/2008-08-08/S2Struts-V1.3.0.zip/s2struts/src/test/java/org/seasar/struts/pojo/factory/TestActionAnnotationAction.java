package org.seasar.struts.pojo.factory;

/**
 * @author Katsuhiko Nagashima
 */
public interface TestActionAnnotationAction {
    
    String exe();

}
