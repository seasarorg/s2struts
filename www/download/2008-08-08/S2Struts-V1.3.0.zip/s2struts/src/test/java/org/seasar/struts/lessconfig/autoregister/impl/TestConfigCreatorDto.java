package org.seasar.struts.lessconfig.autoregister.impl;

public class TestConfigCreatorDto {

}
