package org.seasar.struts.lessconfig.factory;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public class TestValidatorAnnotationOrderForm {

    public static final String classType_VALIDATOR = "required";

    public static final int classType_VALIDATOR_ORDER = 1;

    public void setClassType(String classType) {
    }

    public String getClassType() {
        return null;
    }

    public static final String className_VALIDATOR = "required";

    public static final int className_VALIDATOR_ORDER = 2;

    public void setClassName(String className) {
    }

    public String getClassName() {
        return null;
    }

    public static final String arg_VALIDATOR = "required";

    public static final int arg_VALIDATOR_ORDER = 3;

    public void setArg(String arg) {
    }

    public String getArg() {
        return null;
    }

}
