package org.seasar.struts.pojo;

public class TestPojoActionImpl implements TestPojoAction {

    public String execute() {
        return "success";
    }

}
