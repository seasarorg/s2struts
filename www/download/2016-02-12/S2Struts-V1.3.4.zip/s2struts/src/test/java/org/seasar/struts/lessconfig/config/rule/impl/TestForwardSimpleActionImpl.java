package org.seasar.struts.lessconfig.config.rule.impl;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public class TestForwardSimpleActionImpl implements TestForwardSimpleAction {

}
