package org.seasar.struts.pojo.processor;

import org.apache.struts.action.Action;

/**
 * 
 * @author Katsuhiko Nagashima
 *
 */
public class TestAction extends Action {

}
