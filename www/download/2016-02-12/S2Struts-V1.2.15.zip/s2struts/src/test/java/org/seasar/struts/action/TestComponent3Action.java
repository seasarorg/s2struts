package org.seasar.struts.action;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public interface TestComponent3Action {

    String exe();

}
