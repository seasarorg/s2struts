package org.seasar.struts.action;

/**
 * @author Satoshi Kimura
 */
public class ReturnNullPOJOActionImpl implements ReturnNullPOJOAction {
    public String exe() {
        return null;
    }
}