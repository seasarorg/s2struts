package org.seasar.struts.config;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public interface TestSimpleAction {

    String exe();

}
