package org.seasar.struts.lessconfig.config.rule.impl;

import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.SingletonS2ContainerFactory;
import org.seasar.framework.util.ClassUtil;
import org.seasar.struts.lessconfig.config.StrutsActionFormConfig;
import org.seasar.struts.lessconfig.config.rule.ActionFormNamingRule;
import org.seasar.struts.lessconfig.config.rule.CommonNamingRule;
import org.seasar.struts.lessconfig.factory.StrutsConfigAnnotationHandler;
import org.seasar.struts.lessconfig.factory.StrutsConfigAnnotationHandlerFactory;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public class DefaultActionFormNamingRule implements ActionFormNamingRule {

    // private S2Container container;
    //
    // public void setContainer(S2Container container) {
    // this.container = container;
    // }

    private S2Container getContainer() {
        return SingletonS2ContainerFactory.getContainer();
    }

    public Class toComponentClass(String name) {
        S2Container container = getContainer();
        
        if (container.hasComponentDef(name)) {
            return container.getComponentDef(name).getComponentClass();
        }
        
        Class formClass = null;
        if (name.endsWith("Dto")) {
            String componentName = name.substring(0, name.length() - 3) + "Form";
            if (container.hasComponentDef(componentName)) {
                formClass = container.getComponentDef(componentName).getComponentClass();
            }
        }
        if (name.endsWith("Form")) {
            String componentName = name.substring(0, name.length() - 4) + "Dto";
            if (container.hasComponentDef(componentName)) {
                formClass = container.getComponentDef(componentName).getComponentClass();
            }
        }
        if (formClass != null) {
            StrutsConfigAnnotationHandler annHandler = StrutsConfigAnnotationHandlerFactory.getAnnotationHandler();
            StrutsActionFormConfig strutsActionForm = annHandler.createStrutsActionFormConfig(formClass);
            if (strutsActionForm != null && name.equals(strutsActionForm.name())) {
                return formClass;
            }
        }
        
        return null;
    }

    public String toActionFormName(Class formClass) {
        S2Container container = getContainer();
        if (!container.hasComponentDef(formClass)) {
            String name = ClassUtil.getShortClassName(formClass);
            return CommonNamingRule.decapitalizeName(name);
        }

        return container.getComponentDef(formClass).getComponentName();
    }

}
