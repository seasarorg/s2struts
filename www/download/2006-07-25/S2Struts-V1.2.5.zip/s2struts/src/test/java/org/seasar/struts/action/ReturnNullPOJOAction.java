package org.seasar.struts.action;

/**
 * @author Satoshi Kimura
 */
public interface ReturnNullPOJOAction {
    String exe();

}
