package org.seasar.struts.lessconfig.hotdeploy;

public class TestOndemand1Dto {

}
