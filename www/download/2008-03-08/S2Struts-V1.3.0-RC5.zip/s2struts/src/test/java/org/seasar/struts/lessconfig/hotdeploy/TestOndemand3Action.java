package org.seasar.struts.lessconfig.hotdeploy;

public class TestOndemand3Action {

    public static final String SUCCESS_FORWARD = "/testOndemand.jsp";

    public static final String SUCCESS = "success";

}
