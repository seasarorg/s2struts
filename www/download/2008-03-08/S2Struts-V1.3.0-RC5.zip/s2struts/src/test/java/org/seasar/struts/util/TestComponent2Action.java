package org.seasar.struts.util;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public interface TestComponent2Action {

    String exe();

}
