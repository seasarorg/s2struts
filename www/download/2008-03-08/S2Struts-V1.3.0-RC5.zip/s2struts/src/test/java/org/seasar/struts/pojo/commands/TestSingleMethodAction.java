package org.seasar.struts.pojo.commands;

public interface TestSingleMethodAction {
    
    String execute();

}
