package org.seasar.struts.examples.upload;

public interface UploadAction {
    
    String SUCCESS = "success";
    
    String execute();

}
