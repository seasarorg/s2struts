package org.seasar.struts.examples.download;

public interface DownloadAction {
    
    String execute();

}
