package org.seasar.struts.action;

public class MethodBindingActionImpl implements MethodBindingAction {

    public String exe() {
        return "success";
    }

    public String download() {
        return null;
    }

}
