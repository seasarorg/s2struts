package org.seasar.struts.lessconfig.factory;

import org.seasar.struts.lessconfig.factory.TestStrutsConfigAnnotationAction;

/**
 * @author Satoshi Kimura
 */
public class TestStrutsConfigAnnotationActionImpl implements TestStrutsConfigAnnotationAction {

    public TestStrutsConfigAnnotationActionImpl() {
    }

    public String exe() {
        return SUCCESS;
    }
}
