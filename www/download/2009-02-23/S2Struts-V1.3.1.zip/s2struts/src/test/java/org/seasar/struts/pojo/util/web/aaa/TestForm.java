package org.seasar.struts.pojo.util.web.aaa;

public class TestForm {
    public static final String FORM = "";
}
