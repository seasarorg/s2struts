package org.seasar.struts.lessconfig.config.rule.impl.action;

public class PojoComponentActionImpl implements PojoComponentAction {

}
