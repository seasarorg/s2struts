package org.seasar.struts.pojo.commands;

public class TestSingleMethodActionImpl implements TestSingleMethodAction {

    public String execute() {
        return "success";
    }

}
