package org.seasar.struts.pojo.commands;


/**
 * @author Satoshi Kimura
 */
public class TestReturnNullPOJOActionImpl implements TestReturnNullPOJOAction {
    public String exe() {
        return null;
    }
}