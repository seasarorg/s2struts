package org.seasar.struts.pojo.util;

/**
 * @author Katsuhiko Nagashima
 */
public interface TestExportPOJOAction {
	
	String exe();

}
