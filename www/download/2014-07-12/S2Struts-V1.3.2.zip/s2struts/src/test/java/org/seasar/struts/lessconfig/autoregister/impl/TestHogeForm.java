package org.seasar.struts.lessconfig.autoregister.impl;

public class TestHogeForm {

    public static final String FORM = "";
}
