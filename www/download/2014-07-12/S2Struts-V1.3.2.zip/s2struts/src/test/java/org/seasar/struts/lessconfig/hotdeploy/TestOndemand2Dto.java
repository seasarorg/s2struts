package org.seasar.struts.lessconfig.hotdeploy;

public class TestOndemand2Dto {

}
