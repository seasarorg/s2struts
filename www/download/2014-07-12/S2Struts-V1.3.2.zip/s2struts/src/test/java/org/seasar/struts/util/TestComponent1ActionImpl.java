package org.seasar.struts.util;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public class TestComponent1ActionImpl implements TestComponent1Action {

    public String exe() {
        return null;
    }

}
