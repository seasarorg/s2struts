package org.seasar.struts.lessconfig.config.rule.impl.web.aaa;

public class TestForm {
    public static final String FORM = "";
}
