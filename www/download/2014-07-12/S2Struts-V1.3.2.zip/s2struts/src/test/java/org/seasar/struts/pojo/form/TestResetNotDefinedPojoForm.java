package org.seasar.struts.pojo.form;

/**
 * 
 * @author Katsuhiko Nagashima
 */
public class TestResetNotDefinedPojoForm {

}
