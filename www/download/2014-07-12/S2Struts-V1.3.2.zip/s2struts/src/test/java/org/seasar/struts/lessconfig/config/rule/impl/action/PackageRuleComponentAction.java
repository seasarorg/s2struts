package org.seasar.struts.lessconfig.config.rule.impl.action;

import org.apache.struts.action.Action;

public class PackageRuleComponentAction extends Action {

}
