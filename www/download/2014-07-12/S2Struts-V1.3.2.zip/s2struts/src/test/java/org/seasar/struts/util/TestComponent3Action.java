package org.seasar.struts.util;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public interface TestComponent3Action {

    String exe();

}
