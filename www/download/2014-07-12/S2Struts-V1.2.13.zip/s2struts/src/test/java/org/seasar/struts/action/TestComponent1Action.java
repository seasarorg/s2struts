package org.seasar.struts.action;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public interface TestComponent1Action {

    String exe();

}
