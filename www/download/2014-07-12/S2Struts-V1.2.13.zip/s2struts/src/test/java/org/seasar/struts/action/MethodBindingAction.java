package org.seasar.struts.action;

public interface MethodBindingAction {

    String exe();

    String exe(int index);

    String download();

}
