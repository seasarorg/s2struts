package org.seasar.struts.action;

/**
 * @author skimura
 */
public interface TestServiceMarker {

}
