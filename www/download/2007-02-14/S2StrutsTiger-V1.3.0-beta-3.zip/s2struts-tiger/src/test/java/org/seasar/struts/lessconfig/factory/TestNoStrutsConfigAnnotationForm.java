package org.seasar.struts.lessconfig.factory;

import org.seasar.struts.lessconfig.factory.TestStrutsConfigAnnotationForm;

/**
 * @author Katsuhiko Nagashima
 */
public class TestNoStrutsConfigAnnotationForm extends TestStrutsConfigAnnotationForm {

}
