package org.seasar.struts.util;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public interface TestComponent1Action {

    String exe();

}
