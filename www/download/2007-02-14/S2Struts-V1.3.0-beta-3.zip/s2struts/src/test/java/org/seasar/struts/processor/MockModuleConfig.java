package org.seasar.struts.processor;

import org.apache.struts.action.ActionMapping;
import org.apache.struts.config.ActionConfig;
import org.apache.struts.config.ControllerConfig;
import org.apache.struts.config.ExceptionConfig;
import org.apache.struts.config.FormBeanConfig;
import org.apache.struts.config.ForwardConfig;
import org.apache.struts.config.MessageResourcesConfig;
import org.apache.struts.config.ModuleConfig;
import org.apache.struts.config.PlugInConfig;

/**
 * 
 * @author Katsuhiko Nagashima
 *
 */
public class MockModuleConfig implements ModuleConfig {

    public void addActionConfig(ActionConfig arg0) {
        // TODO Auto-generated method stub

    }

    public void addExceptionConfig(ExceptionConfig arg0) {
        // TODO Auto-generated method stub

    }

    public void addFormBeanConfig(FormBeanConfig arg0) {
        // TODO Auto-generated method stub

    }

    public void addForwardConfig(ForwardConfig arg0) {
        // TODO Auto-generated method stub

    }

    public void addMessageResourcesConfig(MessageResourcesConfig arg0) {
        // TODO Auto-generated method stub

    }

    public void addPlugInConfig(PlugInConfig arg0) {
        // TODO Auto-generated method stub

    }

    public ActionConfig findActionConfig(String arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    public ActionConfig[] findActionConfigs() {
        // TODO Auto-generated method stub
        return null;
    }

    public ExceptionConfig findExceptionConfig(String arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    public ExceptionConfig[] findExceptionConfigs() {
        // TODO Auto-generated method stub
        return null;
    }

    public FormBeanConfig findFormBeanConfig(String arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    public FormBeanConfig[] findFormBeanConfigs() {
        // TODO Auto-generated method stub
        return null;
    }

    public ForwardConfig findForwardConfig(String arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    public ForwardConfig[] findForwardConfigs() {
        // TODO Auto-generated method stub
        return null;
    }

    public MessageResourcesConfig findMessageResourcesConfig(String arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    public MessageResourcesConfig[] findMessageResourcesConfigs() {
        // TODO Auto-generated method stub
        return null;
    }

    public PlugInConfig[] findPlugInConfigs() {
        // TODO Auto-generated method stub
        return null;
    }

    public void freeze() {
        // TODO Auto-generated method stub

    }

    public String getActionFormBeanClass() {
        return FormBeanConfig.class.getName();
    }

    public String getActionForwardClass() {
        return ForwardConfig.class.getName();
    }

    public String getActionMappingClass() {
        return ActionMapping.class.getName();
    }

    public boolean getConfigured() {
        // TODO Auto-generated method stub
        return false;
    }

    public ControllerConfig getControllerConfig() {
        // TODO Auto-generated method stub
        return null;
    }

    public String getPrefix() {
        // TODO Auto-generated method stub
        return null;
    }

    public void removeActionConfig(ActionConfig arg0) {
        // TODO Auto-generated method stub

    }

    public void removeExceptionConfig(ExceptionConfig arg0) {
        // TODO Auto-generated method stub

    }

    public void removeFormBeanConfig(FormBeanConfig arg0) {
        // TODO Auto-generated method stub

    }

    public void removeForwardConfig(ForwardConfig arg0) {
        // TODO Auto-generated method stub

    }

    public void removeMessageResourcesConfig(MessageResourcesConfig arg0) {
        // TODO Auto-generated method stub

    }

    public void setActionFormBeanClass(String arg0) {
        // TODO Auto-generated method stub

    }

    public void setActionForwardClass(String arg0) {
        // TODO Auto-generated method stub

    }

    public void setActionMappingClass(String arg0) {
        // TODO Auto-generated method stub

    }

    public void setControllerConfig(ControllerConfig arg0) {
        // TODO Auto-generated method stub

    }

    public void setPrefix(String arg0) {
        // TODO Auto-generated method stub

    }

    public ExceptionConfig findException(Class arg0) {
        // TODO Auto-generated method stub
        return null;
    }

}
