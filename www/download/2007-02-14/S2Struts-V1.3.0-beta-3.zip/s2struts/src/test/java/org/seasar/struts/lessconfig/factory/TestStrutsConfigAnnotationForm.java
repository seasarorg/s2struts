package org.seasar.struts.lessconfig.factory;

/**
 * @author Katsuhiko Nagashima
 */
public class TestStrutsConfigAnnotationForm {

    public static final String FORM = "testFormName, restricted=false";

}
