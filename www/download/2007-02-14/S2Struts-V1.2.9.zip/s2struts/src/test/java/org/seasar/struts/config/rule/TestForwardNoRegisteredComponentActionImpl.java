package org.seasar.struts.config.rule;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public class TestForwardNoRegisteredComponentActionImpl implements TestForwardNoRegisteredComponentAction {

    public String exe() {
        return null;
    }

}
