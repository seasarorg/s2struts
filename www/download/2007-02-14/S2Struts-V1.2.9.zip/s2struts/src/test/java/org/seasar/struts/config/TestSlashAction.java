package org.seasar.struts.config;

/**
 * 
 * @author Katsuhiko Nagashima
 *
 */
public interface TestSlashAction {

    String exe();

}
