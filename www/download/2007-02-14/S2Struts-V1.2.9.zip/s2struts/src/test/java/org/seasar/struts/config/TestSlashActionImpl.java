package org.seasar.struts.config;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public class TestSlashActionImpl implements TestSlashAction {

    public String exe() {
        return null;
    }

}
