package org.seasar.struts.config;

public class TestHogeForm {

    String FORM = "";

}
