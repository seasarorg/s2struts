package org.seasar.struts.config;

public interface TestHogeAction {

    String ACTION = "";

    String execute();
}
