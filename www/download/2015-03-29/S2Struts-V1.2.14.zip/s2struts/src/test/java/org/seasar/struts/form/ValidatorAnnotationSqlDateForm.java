package org.seasar.struts.form;

import java.sql.Date;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public class ValidatorAnnotationSqlDateForm {

    public static final String autoSqlDate_VALIDATOR_ARGS = "AutoSqlDate, resource=false";

    public void setAutoSqlDate(Date autoSqlDate) {
    }

    public Date getAutoSqlDate() {
        return null;
    }

}
