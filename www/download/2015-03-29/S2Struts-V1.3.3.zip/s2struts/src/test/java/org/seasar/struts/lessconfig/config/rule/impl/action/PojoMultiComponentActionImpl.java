package org.seasar.struts.lessconfig.config.rule.impl.action;

public class PojoMultiComponentActionImpl implements PojoComponentOneAction, PojoComponentTwoAction {

}
