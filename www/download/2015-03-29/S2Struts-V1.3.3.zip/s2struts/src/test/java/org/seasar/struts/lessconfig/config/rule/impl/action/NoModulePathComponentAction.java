package org.seasar.struts.lessconfig.config.rule.impl.action;

import org.apache.struts.action.Action;

public class NoModulePathComponentAction extends Action {

}
