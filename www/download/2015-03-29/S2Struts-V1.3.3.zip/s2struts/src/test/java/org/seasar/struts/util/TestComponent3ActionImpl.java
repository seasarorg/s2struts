package org.seasar.struts.util;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public class TestComponent3ActionImpl implements TestComponent3Action {

    public String exe() {
        return null;
    }

}
