package org.seasar.struts.util;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public class TestComponent2ActionImpl implements TestComponent2Action {

    public String exe() {
        return null;
    }

}
