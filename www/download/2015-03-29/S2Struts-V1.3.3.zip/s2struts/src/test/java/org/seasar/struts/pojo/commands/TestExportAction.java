package org.seasar.struts.pojo.commands;

/**
 * @author Katsuhiko Nagashima
 */
public interface TestExportAction {

    String exe();
    
}
