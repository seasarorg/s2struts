package org.seasar.struts.action.impl;

/**
 * @author skimura
 */
public interface TestServiceMarker {

}
