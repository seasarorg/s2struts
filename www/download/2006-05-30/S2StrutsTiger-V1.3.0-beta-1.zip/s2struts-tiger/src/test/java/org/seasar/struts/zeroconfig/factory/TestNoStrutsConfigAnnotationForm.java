package org.seasar.struts.zeroconfig.factory;

/**
 * @author Katsuhiko Nagashima
 */
public class TestNoStrutsConfigAnnotationForm extends TestStrutsConfigAnnotationForm {

}
