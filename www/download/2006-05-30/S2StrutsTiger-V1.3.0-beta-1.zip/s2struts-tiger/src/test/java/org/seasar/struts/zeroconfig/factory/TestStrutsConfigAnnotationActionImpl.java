package org.seasar.struts.zeroconfig.factory;

/**
 * @author Satoshi Kimura
 */
public class TestStrutsConfigAnnotationActionImpl implements TestStrutsConfigAnnotationAction {

    public TestStrutsConfigAnnotationActionImpl() {
    }

    public String exe() {
        return SUCCESS;
    }
}
