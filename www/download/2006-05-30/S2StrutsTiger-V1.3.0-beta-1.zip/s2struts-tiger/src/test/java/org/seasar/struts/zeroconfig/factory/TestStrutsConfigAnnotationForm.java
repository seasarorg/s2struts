package org.seasar.struts.zeroconfig.factory;

import org.seasar.struts.annotation.tiger.StrutsActionForm;

/**
 * @author Katsuhiko Nagashima
 */
@StrutsActionForm(name = "testFormName")
public class TestStrutsConfigAnnotationForm {

}
