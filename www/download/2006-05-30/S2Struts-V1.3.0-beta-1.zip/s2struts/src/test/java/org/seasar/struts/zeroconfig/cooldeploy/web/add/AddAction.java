package org.seasar.struts.zeroconfig.cooldeploy.web.add;

public interface AddAction {

}
