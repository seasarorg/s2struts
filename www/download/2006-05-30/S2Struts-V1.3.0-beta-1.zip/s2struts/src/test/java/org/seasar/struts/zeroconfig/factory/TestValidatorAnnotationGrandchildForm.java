package org.seasar.struts.zeroconfig.factory;

public class TestValidatorAnnotationGrandchildForm {

    public static final String required_VALIDATOR = "required";
    public static final String required_VALIDATOR_ARGS = "GrandchildRequired, resource=false";

    public void setRequired(String required) {
    }
    
    public static final String integer_VALIDATOR_ARGS = "GrandchildInteger, resource=false";
    
    public void setInteger(int integer) {
    }
    
    public void setNoValidate(String noValidate) {
    }

}
