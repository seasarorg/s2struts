package org.seasar.struts.zeroconfig.factory;

/**
 * @author Katsuhiko Nagashima
 */
public class TestStrutsConfigAnnotationForm {

    public static final String FORM = "testFormName";

}
