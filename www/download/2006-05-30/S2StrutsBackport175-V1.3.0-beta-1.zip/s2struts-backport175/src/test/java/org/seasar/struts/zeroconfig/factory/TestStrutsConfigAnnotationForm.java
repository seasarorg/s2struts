package org.seasar.struts.zeroconfig.factory;

/**
 * @author Katsuhiko Nagashima
 * @org.seasar.struts.annotation.backport175.StrutsActionForm(name = "testFormName")
 */
public class TestStrutsConfigAnnotationForm {

}
