package org.seasar.struts.unit;

/**
 * @author Satoshi Kimura
 */
public interface TestService {
    boolean service();
}