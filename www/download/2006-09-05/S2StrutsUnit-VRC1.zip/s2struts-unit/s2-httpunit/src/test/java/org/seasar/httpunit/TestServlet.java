package org.seasar.httpunit;

import javax.servlet.http.HttpServlet;

/**
 * @author Satoshi Kimura
 */
public class TestServlet extends HttpServlet {
}