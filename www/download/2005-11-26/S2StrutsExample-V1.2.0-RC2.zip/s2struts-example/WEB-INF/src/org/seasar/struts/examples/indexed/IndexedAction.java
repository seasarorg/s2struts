package org.seasar.struts.examples.indexed;

public interface IndexedAction {
    
    String SUCCESS = "success";
    
    String execute();

}
