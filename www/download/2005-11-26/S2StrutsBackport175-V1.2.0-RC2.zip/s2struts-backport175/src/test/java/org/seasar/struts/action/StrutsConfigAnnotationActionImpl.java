package org.seasar.struts.action;


/**
 * @author Satoshi Kimura
 */
public class StrutsConfigAnnotationActionImpl implements StrutsConfigAnnotationAction {

    public StrutsConfigAnnotationActionImpl() {
    }

    public String exe() {
        return SUCCESS;
    }
}
