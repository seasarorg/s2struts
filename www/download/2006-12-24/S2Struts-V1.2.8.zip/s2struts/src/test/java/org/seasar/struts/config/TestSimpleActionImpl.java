package org.seasar.struts.config;

/**
 * 
 * @author Katsuhiko Nagashima
 *
 */
public class TestSimpleActionImpl implements TestSimpleAction {

    public String exe() {
        return null;
    }

}
