package org.seasar.struts.form;

/**
 * 
 * @author Katsuhiko Nagashima
 *
 */
public class ValidatorAnnotationOrderForm {

    public static final String classType_VALIDATOR = "required";

    public static final int classType_VALIDATOR_ORDER = 1;

    public void setClassType(String classType) {
    }

    public static final String className_VALIDATOR = "required";

    public static final int className_VALIDATOR_ORDER = 2;

    public void setClassName(String className) {
    }

    public static final String arg_VALIDATOR = "required";

    public static final int arg_VALIDATOR_ORDER = 3;

    public void setArg(String arg) {
    }

}
