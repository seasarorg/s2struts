package org.seasar.struts.config.rule;

/**
 * 
 * @author Katsuhiko Nagashima
 * 
 */
public class TestNotForwardSimpleActionImpl implements TestNotForwardSimpleAction {

}
